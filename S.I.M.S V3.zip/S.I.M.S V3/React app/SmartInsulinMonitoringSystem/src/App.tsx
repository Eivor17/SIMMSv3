import React, { useState, useEffect } from 'react';
import './App.css';

const App = () => {
  const [status, setStatus] = useState({
    doseActive: 'NO',
    vialTaken: 'NO', 
    vialReplaced: 'NO',
    currentWeight: '0.00 g',
    initialWeight: '0.00 g',
    wifi: 'Disconnected',
    time: 'Not Synced'
  });

  const [alerts, setAlerts] = useState([]);
  const [esp32IP, setEsp32IP] = useState('192.168.28.75');
  const [connectionStatus, setConnectionStatus] = useState('Disconnected');
  const [debugInfo, setDebugInfo] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  
  // New states for dose management
  const [doses, setDoses] = useState([]);
  const [showDoseModal, setShowDoseModal] = useState(false);
  const [newDose, setNewDose] = useState({
    hour: 8,
    minute: 0,
    ml: 2.0,
    expectedWeight: 5.0
  });

  // New states for UI features
  const [showDebug, setShowDebug] = useState(false);
  const [showDocumentation, setShowDocumentation] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  // Apply dark mode class to body
  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }, [darkMode]);

  // Test connection function
  const testConnection = async () => {
    setIsTesting(true);
    setDebugInfo('Testing connection...');
    
    try {
      const response = await fetch(`http://${esp32IP}/api/status`, {
        method: 'GET',
        mode: 'cors',
        headers: {
          'Accept': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      setDebugInfo(`✅ Connected successfully!`);
      
      setStatus({
        doseActive: data.doseActive ? 'YES' : 'NO',
        vialTaken: data.vialTaken ? 'YES' : 'NO',
        vialReplaced: data.vialReplaced ? 'YES' : 'NO',
        currentWeight: `${data.currentWeight?.toFixed(2) || '0.00'} g`,
        initialWeight: `${data.initialWeight?.toFixed(2) || '0.00'} g`,
        wifi: data.wifiConnected ? 'Connected' : 'Disconnected',
        time: data.timeSynced ? 'Synced' : 'Not Synced'
      });
      
      setConnectionStatus('Connected');
      
    } catch (error) {
      const errorMsg = `❌ Connection failed: ${error.message}`;
      setDebugInfo(errorMsg);
      setConnectionStatus('Disconnected');
      console.error('Connection test failed:', error);
    } finally {
      setIsTesting(false);
    }
  };

  // Fetch current dose schedule
  const fetchDoses = async () => {
    try {
      const response = await fetch(`http://${esp32IP}/api/doses`, {
        method: 'GET',
        mode: 'cors'
      });
      
      if (response.ok) {
        const data = await response.json();
        setDoses(Array.isArray(data) ? data : []);
        console.log('Fetched doses:', data);
      } else {
        console.error('Failed to fetch doses:', response.status);
      }
    } catch (error) {
      console.error('Failed to fetch doses:', error);
    }
  };

  // Add a new dose
  const addDose = async () => {
    setIsTesting(true);
    setDebugInfo('Adding dose...');
    
    try {
      const response = await fetch(`http://${esp32IP}/api/doses/add`, {
        method: 'POST',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newDose),
      });

      const result = await response.json();
      
      if (response.ok) {
        setShowDoseModal(false);
        setNewDose({ hour: 8, minute: 0, ml: 2.0, expectedWeight: 5.0 });
        await fetchDoses(); // Refresh the list
        setDebugInfo('✅ Dose added successfully!');
      } else {
        setDebugInfo(`❌ Failed to add dose: ${result.error || response.status}`);
      }
    } catch (error) {
      setDebugInfo(`❌ Error adding dose: ${error.message}`);
      console.error('Add dose error:', error);
    } finally {
      setIsTesting(false);
    }
  };

  // Update entire dose schedule
  const updateDoses = async (updatedDoses) => {
    try {
      const response = await fetch(`http://${esp32IP}/api/doses`, {
        method: 'POST',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedDoses),
      });

      if (response.ok) {
        await fetchDoses(); // Refresh the list
        setDebugInfo('✅ Dose schedule updated!');
      } else {
        setDebugInfo('❌ Failed to update doses');
      }
    } catch (error) {
      setDebugInfo(`❌ Error updating doses: ${error.message}`);
    }
  };

  // Clear all doses
  const clearDoses = async () => {
    if (window.confirm('Are you sure you want to clear all doses?')) {
      setIsTesting(true);
      try {
        const response = await fetch(`http://${esp32IP}/api/doses/clear`, {
          method: 'POST',
          mode: 'cors'
        });

        if (response.ok) {
          await fetchDoses();
          setDebugInfo('✅ All doses cleared!');
        } else {
          setDebugInfo('❌ Failed to clear doses');
        }
      } catch (error) {
        setDebugInfo(`❌ Error clearing doses: ${error.message}`);
      } finally {
        setIsTesting(false);
      }
    }
  };

  // Delete a specific dose
  const deleteDose = async (index) => {
    if (window.confirm('Are you sure you want to delete this dose?')) {
      setIsTesting(true);
      try {
        const updatedDoses = doses.filter((_, i) => i !== index);
        // Fill remaining slots with empty doses
        while (updatedDoses.length < 4) {
          updatedDoses.push({ hour: 0, minute: 0, ml: 0, expectedWeight: 0, active: false });
        }
        await updateDoses(updatedDoses);
      } catch (error) {
        setDebugInfo(`❌ Error deleting dose: ${error.message}`);
      } finally {
        setIsTesting(false);
      }
    }
  };

  // Manual connection test
  const runFullConnectionTest = async () => {
    setIsTesting(true);
    setDebugInfo('Running full connection test...\n');
    
    await testConnection();
    await fetchDoses();
    
    setIsTesting(false);
  };

  // Fetch status periodically
  useEffect(() => {
    const fetchStatus = async () => {
      if (isTesting || connectionStatus === 'Testing') return;
      
      try {
        const response = await fetch(`http://${esp32IP}/api/status`, {
          mode: 'cors'
        });
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        setStatus({
          doseActive: data.doseActive ? 'YES' : 'NO',
          vialTaken: data.vialTaken ? 'YES' : 'NO',
          vialReplaced: data.vialReplaced ? 'YES' : 'NO',
          currentWeight: `${data.currentWeight?.toFixed(2) || '0.00'} g`,
          initialWeight: `${data.initialWeight?.toFixed(2) || '0.00'} g`,
          wifi: data.wifiConnected ? 'Connected' : 'Disconnected',
          time: data.timeSynced ? 'Synced' : 'Not Synced'
        });
        
        setConnectionStatus('Connected');
      } catch (error) {
        setConnectionStatus('Disconnected');
      }
    };

    if (esp32IP && !isTesting) {
      const interval = setInterval(fetchStatus, 2000);
      fetchStatus();
      fetchDoses(); // Also fetch doses on initial load
      
      return () => clearInterval(interval);
    }
  }, [esp32IP, isTesting]);

  // Fetch alerts periodically
  useEffect(() => {
    const fetchAlerts = async () => {
      if (isTesting || connectionStatus === 'Disconnected') return;
      
      try {
        const response = await fetch(`http://${esp32IP}/api/alerts`, {
          mode: 'cors'
        });
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        setAlerts(Array.isArray(data) ? data.reverse() : []);
      } catch (error) {
        console.log('Failed to fetch alerts');
      }
    };

    if (esp32IP && !isTesting) {
      const interval = setInterval(fetchAlerts, 3000);
      fetchAlerts();
      
      return () => clearInterval(interval);
    }
  }, [esp32IP, isTesting, connectionStatus]);

  const getAlertIcon = (alert) => {
    if (alert.includes('DOSE START')) return '💊';
    if (alert.includes('VIAL TAKEN')) return '⬆️';
    if (alert.includes('VIAL REPLACED')) return '⬇️';
    if (alert.includes('MEDICINE TAKEN')) return '📊';
    if (alert.includes('RESULT') && alert.includes('✓')) return '✅';
    if (alert.includes('RESULT') && alert.includes('✗')) return '❌';
    if (alert.includes('DOSE COMPLETE')) return '🏁';
    if (alert.includes('DOSE CANCELLED')) return '⏰';
    if (alert.includes('SYSTEM') || alert.includes('AUTO TARE')) return '📡';
    if (alert.includes('WEIGHT')) return '⚖️';
    return '📢';
  };

  const getAlertColor = (alert) => {
    if (alert.includes('RESULT ✓') || alert.includes('DOSE COMPLETE')) return '#4caf50';
    if (alert.includes('RESULT ✗') || alert.includes('CANCELLED')) return '#f44336';
    return '#2196f3';
  };

  const formatTime = (hour, minute) => {
    const hour12 = hour % 12 || 12;
    const period = hour < 12 ? 'AM' : 'PM';
    return `${hour12}:${minute.toString().padStart(2, '0')} ${period}`;
  };

  // API Documentation content
  const apiDocumentation = `
# Smart Insulin Monitoring System - API Documentation

## Base URL
http://[ESP32_IP_ADDRESS]

## Endpoints

### 1. Get System Status
**GET** \`/api/status\`

Returns current system status including dose activity, weight, and connection status.

**Response:**
\`\`\`json
{
  "doseActive": false,
  "vialTaken": false,
  "vialReplaced": false,
  "currentWeight": 125.50,
  "wifiConnected": true,
  "timeSynced": true,
  "initialWeight": 0.00
}
\`\`\`

### 2. Get Alerts
**GET** \`/api/alerts\`

Returns the last 20 system alerts and events.

**Response:**
\`\`\`json
[
  "[SYSTEM] WiFi connected - IP: 192.168.1.100",
  "[DOSE START] 2.0ml at 3:00PM",
  "[VIAL TAKEN] Vial removed from scale"
]
\`\`\`

### 3. Get Dose Schedule
**GET** \`/api/doses\`

Returns the current dose schedule.

**Response:**
\`\`\`json
[
  {
    "id": 0,
    "hour": 8,
    "minute": 0,
    "ml": 2.0,
    "expectedWeight": 5.0,
    "active": true
  }
]
\`\`\`

### 4. Update Dose Schedule
**POST** \`/api/doses\`

Update the entire dose schedule.

**Body:**
\`\`\`json
[
  {
    "hour": 8,
    "minute": 0,
    "ml": 2.0,
    "expectedWeight": 5.0
  },
  {
    "hour": 12,
    "minute": 0,
    "ml": 2.0,
    "expectedWeight": 5.0
  }
]
\`\`\`

### 5. Add Single Dose
**POST** \`/api/doses/add\`

Add a single dose to the schedule.

**Body:**
\`\`\`json
{
  "hour": 8,
  "minute": 0,
  "ml": 2.0,
  "expectedWeight": 5.0
}
\`\`\`

### 6. Clear All Doses
**POST** \`/api/doses/clear\`

Clear all scheduled doses.

### 7. Debug Information
**GET** \`/api/debug\`

Returns detailed system debug information.

## Error Responses

All endpoints return appropriate HTTP status codes:

- \`200\` - Success
- \`400\` - Bad Request (invalid JSON or data)
- \`404\` - Not Found
- \`500\` - Internal Server Error

Error response format:
\`\`\`json
{
  "error": "Error description"
}
\`\`\`
`;

  return (
    <div className={`app ${darkMode ? 'dark-mode' : ''}`}>
      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-brand">
          <span className="nav-icon">💊</span>
          Smart Insulin Monitoring System
          <span className="connection-status" style={{ 
            color: connectionStatus === 'Connected' ? '#4caf50' : '#f44336',
            fontSize: '0.8rem',
            marginLeft: '1rem'
          }}>
            {connectionStatus}
          </span>
        </div>
        
        <div className="nav-controls">
          <button 
            className={`nav-btn ${showDebug ? 'active' : ''}`}
            onClick={() => setShowDebug(!showDebug)}
            title="Toggle Debug Panel"
          >
            🐛 Debug
          </button>
          
          <button 
            className={`nav-btn ${showDocumentation ? 'active' : ''}`}
            onClick={() => setShowDocumentation(!showDocumentation)}
            title="API Documentation"
          >
            📚 Docs
          </button>
          
          <button 
            className="nav-btn"
            onClick={() => setDarkMode(!darkMode)}
            title={`Switch to ${darkMode ? 'Light' : 'Dark'} Mode`}
          >
            {darkMode ? '☀️' : '🌙'} Theme
          </button>
        </div>

        <div className="nav-status">
          <span className="status-item">Dose Active: <strong>{status.doseActive}</strong></span>
          <span className="status-item">Vial Taken: <strong>{status.vialTaken}</strong></span>
          <span className="status-item">Vial Replaced: <strong>{status.vialReplaced}</strong></span>
          <span className="status-item">Current Weight: <strong>{status.currentWeight}</strong></span>
        </div>
      </nav>

      {/* Main Content */}
      <main className="main-content">
        {/* Documentation Modal */}
        {showDocumentation && (
          <div className="modal-overlay">
            <div className="modal documentation-modal">
              <div className="modal-header">
                <h3>API Documentation</h3>
                <button 
                  className="close-btn"
                  onClick={() => setShowDocumentation(false)}
                >
                  ✕
                </button>
              </div>
              <div className="modal-content">
                <div className="documentation-content">
                  <pre>{apiDocumentation}</pre>
                </div>
              </div>
              <div className="modal-actions">
                <button 
                  className="btn-primary"
                  onClick={() => setShowDocumentation(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="alerts-container">
          <h2 className="alerts-title">Real-time Updates</h2>
          <div className="alerts-list">
            {alerts.length === 0 ? (
              <div className="no-alerts">No alerts yet. Waiting for updates...</div>
            ) : (
              alerts.map((alert, index) => (
                <div 
                  key={index} 
                  className="alert-card"
                  style={{ borderLeftColor: getAlertColor(alert) }}
                >
                  <div className="alert-header">
                    <span className="alert-icon">{getAlertIcon(alert)}</span>
                    <span className="alert-message">{alert}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Dose Schedule Section */}
        <div className="dose-schedule-section">
          <div className="section-header">
            <h3>Dose Schedule</h3>
            <div className="dose-actions">
              <button 
                className="btn-primary"
                onClick={() => setShowDoseModal(true)}
                disabled={isTesting || connectionStatus !== 'Connected'}
              >
                Add New Dose
              </button>
              <button 
                className="btn-secondary"
                onClick={clearDoses}
                disabled={isTesting || connectionStatus !== 'Connected'}
              >
                Clear All
              </button>
            </div>
          </div>

          <div className="doses-list">
            {doses.filter(dose => dose.active).length === 0 ? (
              <div className="no-doses">No doses scheduled. Add your first dose above.</div>
            ) : (
              doses
                .filter(dose => dose.active)
                .map((dose, index) => (
                  <div key={index} className="dose-card">
                    <div className="dose-info">
                      <span className="dose-time">{formatTime(dose.hour, dose.minute)}</span>
                      <span className="dose-amount">{dose.ml} ml ({dose.expectedWeight}g)</span>
                    </div>
                    <button 
                      className="btn-delete"
                      onClick={() => deleteDose(index)}
                      disabled={isTesting || connectionStatus !== 'Connected'}
                    >
                      Delete
                    </button>
                  </div>
                ))
            )}
          </div>
        </div>

        {/* Debug Section - Conditionally Rendered */}
        {showDebug && (
          <div className="debug-section">
            <h3>Connection Debug</h3>
            
            <div className="config-section">
              <label>
                ESP32 IP Address:
                <input 
                  type="text" 
                  value={esp32IP}   
                  onChange={(e) => setEsp32IP(e.target.value.replace(/\s/g, ''))}
                  placeholder="192.168.1.100"
                  disabled={isTesting}
                />
              </label>
              <small>Make sure this matches your ESP32's actual IP address</small>
            </div>

            <div className="test-buttons">
              <button 
                onClick={runFullConnectionTest}
                disabled={isTesting}
                className="test-button"
              >
                {isTesting ? 'Testing...' : 'Test All Connections'}
              </button>
              
              <button 
                onClick={() => {
                  setDebugInfo('');
                  setConnectionStatus('Disconnected');
                }}
                disabled={isTesting}
                className="clear-button"
              >
                Clear Debug
              </button>
            </div>

            {debugInfo && (
              <div className="debug-info">
                <h4>Debug Information:</h4>
                <pre>{debugInfo}</pre>
                
                <div className="direct-links">
                  <p>Test these URLs directly in your browser:</p>
                  <a href={`http://${esp32IP}/api/status`} target="_blank" rel="noopener noreferrer">
                    http://{esp32IP}/api/status
                  </a>
                  <br />
                  <a href={`http://${esp32IP}/api/alerts`} target="_blank" rel="noopener noreferrer">
                    http://{esp32IP}/api/alerts
                  </a>
                  <br />
                  <a href={`http://${esp32IP}/api/doses`} target="_blank" rel="noopener noreferrer">
                    http://{esp32IP}/api/doses
                  </a>
                </div>
              </div>
            )}

            <div className="status-details">
              <h4>Detailed Status:</h4>
              <div className="status-grid">
                <div className="status-item-detailed">
                  <span>WiFi:</span>
                  <strong>{status.wifi}</strong>
                </div>
                <div className="status-item-detailed">
                  <span>Time Sync:</span>
                  <strong>{status.time}</strong>
                </div>
                <div className="status-item-detailed">
                  <span>Initial Weight:</span>
                  <strong>{status.initialWeight}</strong>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Add Dose Modal */}
      {showDoseModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Add New Dose</h3>
            <div className="modal-content">
              <div className="form-group">
                <label>Time:</label>
                <div className="time-inputs">
                  <select 
                    value={newDose.hour} 
                    onChange={(e) => setNewDose({...newDose, hour: parseInt(e.target.value)})}
                  >
                    {Array.from({length: 24}, (_, i) => (
                      <option key={i} value={i}>
                        {i === 0 ? '12 AM' : i === 12 ? '12 PM' : i > 12 ? `${i-12} PM` : `${i} AM`}
                      </option>
                    ))}
                  </select>
                  <span>:</span>
                  <select 
                    value={newDose.minute} 
                    onChange={(e) => setNewDose({...newDose, minute: parseInt(e.target.value)})}
                  >
                    {Array.from({length: 60}, (_, i) => (
                      <option key={i} value={i}>{i.toString().padStart(2, '0')}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label>Medicine Amount (ml):</label>
                <input 
                  type="number" 
                  step="0.1"
                  min="0.1"
                  max="10"
                  value={newDose.ml}
                  onChange={(e) => setNewDose({...newDose, ml: parseFloat(e.target.value)})}
                />
              </div>
              <div className="form-group">
                <label>Expected Weight (g):</label>
                <input 
                  type="number" 
                  step="0.1"
                  min="0.1"
                  max="50"
                  value={newDose.expectedWeight}
                  onChange={(e) => setNewDose({...newDose, expectedWeight: parseFloat(e.target.value)})}
                />
              </div>
            </div>
            <div className="modal-actions">
              <button 
                className="btn-secondary" 
                onClick={() => setShowDoseModal(false)}
                disabled={isTesting}
              >
                Cancel
              </button>
              <button 
                className="btn-primary" 
                onClick={addDose}
                disabled={isTesting}
              >
                {isTesting ? 'Adding...' : 'Add Dose'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;