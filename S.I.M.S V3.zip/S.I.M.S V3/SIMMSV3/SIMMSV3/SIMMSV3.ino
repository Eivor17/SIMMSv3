#include <HX711.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <WiFi.h>
#include "time.h"
#include <WebServer.h>
#include <ArduinoJson.h>
#include <ESP32Servo.h>

// HX711 – for load cell
const int dataPin = 19;
const int clockPin = 18;
float scale_factor = 232.0;
HX711 loadcell;

// Buzzer
const int buzzerPin = 4;

// Built-in LED - Turn it OFF
const int builtInLedPin = LED_BUILTIN;

// LCD
LiquidCrystal_I2C lcd(0x27,16,2);
#define SDA_PIN 33
#define SCL_PIN 34

// Servo Motor Configuration
const int servoPin = 13;
Servo myServo;

// Motor Calibration data
float degreesPerSecond = 198.4;  // Calibrated speed
const int CONSTANT_SPEED = 75;   // Fixed speed for all rotations

// Day tracking for motor
int lastKnownDay = -1;
bool motorDayPassed = false;

// WiFi credentials
const char* ssid     = "wifi1";
const char* password = "12345678";

// Web Server
WebServer server(80);

// NTP
const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 19800;  // IST
const int daylightOffset_sec = 0;

// Dose schedule
struct Dose {
  int hour;
  int minute;
  float ml;
  float expectedWeight;
};

#define DOSE_COUNT 4
Dose doses[DOSE_COUNT] = {
  {0, 0, 0, 0},  // Empty slot
  {0, 0, 0, 0},  // Empty slot  
  {0, 0, 0, 0},  // Empty slot
  {0, 0, 0, 0}   // Empty slot
};

// Dose monitoring variables
bool doseActive = false;
Dose currentDose;
float initialVialWeight = 0;    // Weight of vial with medicine
float finalVialWeight = 0;      // Weight after medicine is taken
bool vialTaken = false;
unsigned long vialReplacedTime = 0;
unsigned long doseStartTime = 0;
const unsigned long helpDuration = 5*60*1000; // 5 minutes

// Alert storage
String alerts[20]; // Store last 20 alerts
int alertCount = 0;

// Auto tare
unsigned long stableStart = 0;
bool inStableRange = false;
float lastStableWeight = 0;

// Timing
unsigned long lastLCDupdate = 0;
const unsigned long lcdInterval = 400; // Faster updates for smoother animation

// Smooth scrolling variables
String upcomingText = "";
int scrollPosition = 0;
unsigned long lastScrollUpdate = 0;
const unsigned long scrollInterval = 150; // Smoother scrolling speed
const int scrollGap = 3; // Gap between repetitions
String extendedText = ""; // Store extended text

// WiFi state
bool wifiConnected = false;
bool timeSynced = false;

// For background WiFi connect
unsigned long lastWiFiAttempt = 0;
const unsigned long wifiRetryInterval = 10000; // 10 seconds between attempts

// Prevent double dose triggering
unsigned long lastDoseTrigger = 0;
const unsigned long doseCooldown = 60000; // 1 minute cooldown between doses

// Buzzer
bool buzzerActive = false;
unsigned long buzzerStartTime = 0;
int buzzerPatternStep = 0;
unsigned long lastBuzzerUpdate = 0;
const unsigned long buzzerBeepDuration = 100; // Short beep duration

// ========== FUNCTION DECLARATIONS ==========
void addCORSHeaders();
void setupWebServer();
void addAlert(String message);
String get12HourTime(int hour, int minute);
String getLCDDateTime();
String getCurrentTimestamp();
String buildUpcomingDosesText();
void buildExtendedText();
String getSmoothScrollingText();
void checkDoseStart();
void monitorDose();
void displayDoseScreen();
void displayHomeScreen();
void activateBuzzer();
void updateBuzzer();
void playBeep();
void playDoubleBeep();
void playRisingBeep();
void playErrorBeep();
void playSuccessBeep();
void checkWiFiDetails();

// Motor Functions
void rotateMotorByAngle(float angle);
void checkDayChange();
void rotateOneDay();

// CORS helper function
void addCORSHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
}

// Function to add alert to storage
void addAlert(String message) {
  alerts[alertCount % 20] = message;
  alertCount++;
}

String get12HourTime(int hour, int minute) {
  int hour12 = (hour % 12 == 0) ? 12 : hour % 12;
  String period = (hour < 12) ? "AM" : "PM";
  String timeStr = String(hour12) + ":";
  if (minute < 10) timeStr += "0";
  timeStr += String(minute) + period;
  return timeStr;
}

String getDayOfWeek(int weekday) {
  switch(weekday) {
    case 0: return "Su";
    case 1: return "Mo";
    case 2: return "Tu";
    case 3: return "We";
    case 4: return "Th";
    case 5: return "Fr";
    case 6: return "Sa";
    default: return "???";
  }
}

String getLCDDateTime() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    return "No Time Available";
  }
  
  // Format: "HH:MM(AM/PM) Day DD-MM"
  // Example: "03:45PM We 25-12"
  
  int hour12 = (timeinfo.tm_hour % 12 == 0) ? 12 : timeinfo.tm_hour % 12;
  String period = (timeinfo.tm_hour < 12) ? "AM" : "PM";
  String dayStr = getDayOfWeek(timeinfo.tm_wday);
  
  char timeString[20];
  snprintf(timeString, sizeof(timeString), "%02d:%02d%s %s %02d-%02d", 
           hour12, timeinfo.tm_min, period.c_str(), dayStr.c_str(),
           timeinfo.tm_mday, timeinfo.tm_mon + 1);
  
  return String(timeString);
}

String getCurrentTimestamp() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    return "Time not available";
  }
  char timeString[9];
  strftime(timeString, sizeof(timeString), "%H:%M:%S", &timeinfo);
  return String(timeString);
}

String buildUpcomingDosesText() {
  String text = "";
  for (int i = 0; i < DOSE_COUNT; i++) {
    if (doses[i].hour > 0 || doses[i].minute > 0) {
      text += get12HourTime(doses[i].hour, doses[i].minute);
      text += "(" + String(doses[i].ml,1) + "ml) ";
    }
  }
  
  if (text.length() == 0) {
    text = "No doses scheduled";
  }
  
  return text;
}

void buildExtendedText() {
  upcomingText = buildUpcomingDosesText();
  
  if (upcomingText.length() <= 16) {
    extendedText = upcomingText;
  } else {
    // Manually create the gap spaces
    String gap = "";
    for (int i = 0; i < scrollGap; i++) {
      gap += " ";
    }
    extendedText = upcomingText + gap + upcomingText;
  }
}

String getSmoothScrollingText() {
  if (extendedText.length() <= 16) {
    return extendedText;
  }
  
  // Extract the visible portion
  String visible = extendedText.substring(scrollPosition, scrollPosition + 16);
  
  // Ensure we always return exactly 16 characters
  if (visible.length() < 16) {
    visible += extendedText.substring(0, 16 - visible.length());
  }
  
  return visible;
}

// ========== MOTOR FUNCTIONS ==========

void rotateMotorByAngle(float angle) {
  float rotationTime = (angle / degreesPerSecond) * 1000;
  
  Serial.print("\n🎯 Rotating motor by: ");
  Serial.print(angle, 1);
  Serial.print("° | Time: ");
  Serial.print(rotationTime);
  Serial.println("ms");
  
  // Perform rotation
  myServo.write(CONSTANT_SPEED);
  delay(rotationTime);
  myServo.write(90);
  
  Serial.println("✅ Motor rotation complete!");
  
  String alertMsg = "[MOTOR] Rotated by " + String(angle, 1) + " degrees";
  addAlert(alertMsg);
}

void rotateOneDay() {
  Serial.println("\n🔄 Rotating motor for 1 day (51 degrees)");
  rotateMotorByAngle(51.0);
}

void checkDayChange() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return;
  
  int currentDay = timeinfo.tm_mday;
  
  // Initialize lastKnownDay if not set
  if (lastKnownDay == -1) {
    lastKnownDay = currentDay;
    return;
  }
  
  // Check if day has changed
  if (currentDay != lastKnownDay && !motorDayPassed) {
    motorDayPassed = true;
    rotateOneDay();
    
    String alertMsg = "[MOTOR] Day changed - automatic rotation performed";
    addAlert(alertMsg);
  }
  
  // Reset flag when day changes again
  if (currentDay != lastKnownDay) {
    lastKnownDay = currentDay;
    motorDayPassed = false;
  }
}

void checkDoseStart() {
  if (doseActive) return;
  
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return;
  
  int currentHour = timeinfo.tm_hour;
  int currentMinute = timeinfo.tm_min;
  unsigned long now = millis();
  
  // Prevent double triggering with cooldown
  if (now - lastDoseTrigger < doseCooldown) return;
  
  for (int i = 0; i < DOSE_COUNT; i++) {
    if (currentHour == doses[i].hour && currentMinute == doses[i].minute && doses[i].ml > 0) {
      doseActive = true;
      currentDose = doses[i];
      initialVialWeight = loadcell.get_units(); // Record starting weight
      vialTaken = false;
      vialReplacedTime = 0;
      doseStartTime = now;
      lastDoseTrigger = now;
      
      String alertMsg = "[DOSE START] " + String(currentDose.ml, 1) + "ml at " + get12HourTime(currentHour, currentMinute);
      Serial.println(alertMsg);
      addAlert(alertMsg);
      
      alertMsg = "[INITIAL WEIGHT] " + String(initialVialWeight, 2) + " g";
      Serial.println(alertMsg);
      addAlert(alertMsg);
      
      // Play dose start sound
      playRisingBeep();
      
      break;
    }
  }
}

void monitorDose() {
  if (!doseActive) return;
  
  unsigned long now = millis();
  float currentWeight = loadcell.get_units();
  
  // Vial taken detection - weight drops significantly (vial lifted)
  if (!vialTaken && currentWeight < initialVialWeight - 2.0) { // Weight drops by at least 2g
    vialTaken = true;
    String alertMsg = "[VIAL TAKEN] Vial removed from scale";
    Serial.println(alertMsg);
    addAlert(alertMsg);
    
    alertMsg = "[WEIGHT WHEN TAKEN] " + String(currentWeight, 2) + " g";
    Serial.println(alertMsg);
    addAlert(alertMsg);
    
    // Play vial taken sound
    playDoubleBeep();
  }
  
  // Vial replaced detection
  if (vialTaken && vialReplacedTime == 0) {
    // Check if weight has returned to a stable value (not zero)
    if (currentWeight > 10.0 && abs(currentWeight - lastStableWeight) < 0.5) {
      if (!inStableRange) {
        inStableRange = true;
        stableStart = now;
      } else if (now - stableStart >= 1000) { // Stable for 1 second
        vialReplacedTime = now;
        finalVialWeight = currentWeight;
        
        // Calculate actual medicine taken
        float medicineTaken = initialVialWeight - finalVialWeight;
        
        String alertMsg = "[VIAL REPLACED] Final weight: " + String(finalVialWeight, 2) + " g";
        Serial.println(alertMsg);
        addAlert(alertMsg);
        
        alertMsg = "[MEDICINE TAKEN] Expected: " + String(currentDose.expectedWeight, 1) + "g, Actual: " + String(medicineTaken, 1) + "g";
        Serial.println(alertMsg);
        addAlert(alertMsg);
        
        // Check if correct amount was taken
        if (abs(medicineTaken - currentDose.expectedWeight) <= 1.0) {
          String resultMsg = "[RESULT] Correct dose taken! ✓";
          Serial.println(resultMsg);
          addAlert(resultMsg);
          playSuccessBeep();
        } else {
          String resultMsg = "[RESULT] Incorrect dose! ✗";
          Serial.println(resultMsg);
          addAlert(resultMsg);
          playErrorBeep();
        }
        inStableRange = false;
      }
    } else {
      inStableRange = false;
      lastStableWeight = currentWeight;
    }
  }
  
  // Auto-complete dose after 5 seconds of vial replacement
  if (vialReplacedTime > 0 && now - vialReplacedTime >= 5000) {
    doseActive = false;
    String alertMsg = "[DOSE COMPLETE] Monitoring ended";
    Serial.println(alertMsg);
    addAlert(alertMsg);
  }
  
  // Auto-cancel dose if help timer expires without interaction
  if (!vialTaken && (now - doseStartTime) >= helpDuration) {
    doseActive = false;
    String alertMsg = "[DOSE CANCELLED] No interaction within 5 minutes";
    Serial.println(alertMsg);
    addAlert(alertMsg);
    playErrorBeep();
  }
}

void displayDoseScreen() {
  if (!doseActive) return;
  
  unsigned long now = millis();
  unsigned long timeElapsed = now - doseStartTime;
  int secondsLeft = (helpDuration - timeElapsed) / 1000;
  if (secondsLeft < 0) secondsLeft = 0;
  
  // Clear both lines first
  lcd.setCursor(0,0);
  lcd.print("                ");
  lcd.setCursor(0,1);
  lcd.print("                ");
  
  if (!vialTaken) {
    // First line: Take medicine instruction
    lcd.setCursor(0,0);
    lcd.print("Take ");
    lcd.print(currentDose.ml, 1);
    lcd.print("ml medicine");
    
    // Second line: Help timer
    lcd.setCursor(0,1);
    lcd.print("Help ");
    lcd.print(secondsLeft / 60);
    lcd.print(":");
    if ((secondsLeft % 60) < 10) lcd.print("0");
    lcd.print(secondsLeft % 60);
    
  } else if (vialReplacedTime == 0) {
    // First line: Return vial instruction
    lcd.setCursor(0,0);
    lcd.print("Place vial back");
    
    // Second line: Help timer continues
    lcd.setCursor(0,1);
    lcd.print("Help ");
    lcd.print(secondsLeft / 60);
    lcd.print(":");
    if ((secondsLeft % 60) < 10) lcd.print("0");
    lcd.print(secondsLeft % 60);
    
  } else {
    // Show result after vial is returned
    float medicineTaken = initialVialWeight - finalVialWeight;
    
    // First line: Result message
    lcd.setCursor(0,0);
    if (abs(medicineTaken - currentDose.expectedWeight) <= 1.0) {
      lcd.print("Dose correct!   ");
    } else {
      lcd.print("Check dose!     ");
    }
    
    // Second line: Actual amount taken
    lcd.setCursor(0,1);
    lcd.print("Taken:");
    lcd.print(medicineTaken, 1);
    lcd.print("g");
    
    // Add spaces to clear any remaining characters
    int spacesNeeded = 16 - (6 + String(medicineTaken,1).length() + 1);
    for (int i = 0; i < spacesNeeded; i++) {
      lcd.print(" ");
    }
  }
}

void displayHomeScreen() {
  // First line: Show time and date in format "HH:MM(AM/PM) Day DD-MM"
  lcd.setCursor(0,0);
  String dateTime = getLCDDateTime();
  lcd.print(dateTime);
  // Fill remaining space
  for (int i = dateTime.length(); i < 16; i++) {
    lcd.print(" ");
  }

  // Second line: Always show scrolling doses
  lcd.setCursor(0,1);
  if (upcomingText.length() > 0) {
    lcd.print(getSmoothScrollingText());
  } else {
    lcd.print("Connect WiFi... ");
  }
}

// ========== BUZZER SOUND EFFECTS ==========

void playBeep() {
  digitalWrite(buzzerPin, HIGH);
  delay(100);
  digitalWrite(buzzerPin, LOW);
}

void playDoubleBeep() {
  digitalWrite(buzzerPin, HIGH);
  delay(80);
  digitalWrite(buzzerPin, LOW);
  delay(80);
  digitalWrite(buzzerPin, HIGH);
  delay(80);
  digitalWrite(buzzerPin, LOW);
}

void playRisingBeep() {
  // Short rising pattern: _--___ (Morse-like "A")
  digitalWrite(buzzerPin, HIGH);
  delay(60);
  digitalWrite(buzzerPin, LOW);
  delay(60);
  digitalWrite(buzzerPin, HIGH);
  delay(180);
  digitalWrite(buzzerPin, LOW);
}

void playErrorBeep() {
  // Error pattern: long beep
  digitalWrite(buzzerPin, HIGH);
  delay(300);
  digitalWrite(buzzerPin, LOW);
  delay(100);
  digitalWrite(buzzerPin, HIGH);
  delay(300);
  digitalWrite(buzzerPin, LOW);
}

void playSuccessBeep() {
  // Success pattern: short upbeat beeps
  digitalWrite(buzzerPin, HIGH);
  delay(60);
  digitalWrite(buzzerPin, LOW);
  delay(60);
  digitalWrite(buzzerPin, HIGH);
  delay(60);
  digitalWrite(buzzerPin, LOW);
  delay(60);
  digitalWrite(buzzerPin, HIGH);
  delay(120);
  digitalWrite(buzzerPin, LOW);
}

void activateBuzzer() {
  Serial.println("BUZZER: Playing test sound");
  playDoubleBeep();
  addAlert("[BUZZER] Test sound played");
}

void updateBuzzer() {
  // Simple state machine for buzzer patterns
  // This function is called in loop() but we're using direct delays in sound functions
  // for simplicity and reliability
}

// Test all buzzer sounds
void testAllSounds() {
  Serial.println("Testing all buzzer sounds...");
  
  Serial.println("1. Single beep");
  playBeep();
  delay(1000);
  
  Serial.println("2. Double beep");
  playDoubleBeep();
  delay(1000);
  
  Serial.println("3. Rising beep");
  playRisingBeep();
  delay(1000);
  
  Serial.println("4. Error beep");
  playErrorBeep();
  delay(1000);
  
  Serial.println("5. Success beep");
  playSuccessBeep();
  delay(1000);
  
  Serial.println("Buzzer test complete");
}

// WiFi troubleshooting function
void checkWiFiDetails() {
  Serial.println("\n=== WiFi Details ===");
  Serial.printf("SSID: %s\n", WiFi.SSID().c_str());
  Serial.printf("BSSID: %s\n", WiFi.BSSIDstr().c_str());
  Serial.printf("RSSI: %d dBm\n", WiFi.RSSI());
  Serial.printf("Channel: %d\n", WiFi.channel());
  Serial.printf("IP: %s\n", WiFi.localIP().toString().c_str());
  Serial.printf("Gateway: %s\n", WiFi.gatewayIP().toString().c_str());
  Serial.printf("Subnet: %s\n", WiFi.subnetMask().toString().c_str());
  Serial.printf("DNS: %s\n", WiFi.dnsIP().toString().c_str());
  Serial.println("====================\n");
}

void setupWebServer() {
  // Handle preflight OPTIONS requests for all endpoints
  server.onNotFound([]() {
    if (server.method() == HTTP_OPTIONS) {
      addCORSHeaders();
      server.send(200);
    } else {
      server.send(404, "text/plain", "Not Found");
    }
  });

  // API endpoint for status
  server.on("/api/status", HTTP_GET, []() {
    StaticJsonDocument<512> doc;
    
    doc["doseActive"] = doseActive;
    doc["vialTaken"] = vialTaken;
    doc["vialReplaced"] = vialReplacedTime > 0;
    doc["currentWeight"] = loadcell.get_units();
    doc["wifiConnected"] = wifiConnected;
    doc["timeSynced"] = timeSynced;
    doc["initialWeight"] = initialVialWeight;
    
    String response;
    serializeJson(doc, response);
    
    addCORSHeaders();
    server.send(200, "application/json", response);
  });

  // API endpoint for alerts
  server.on("/api/alerts", HTTP_GET, []() {
    StaticJsonDocument<2048> doc;
    JsonArray alertArray = doc.to<JsonArray>();
    
    int start = max(0, alertCount - 20);
    for (int i = start; i < alertCount; i++) {
      alertArray.add(alerts[i % 20]);
    }
    
    String response;
    serializeJson(doc, response);
    
    addCORSHeaders();
    server.send(200, "application/json", response);
  });

  // API endpoint to get current dose schedule
  server.on("/api/doses", HTTP_GET, []() {
    StaticJsonDocument<1024> doc;
    JsonArray dosesArray = doc.to<JsonArray>();
    
    for (int i = 0; i < DOSE_COUNT; i++) {
      JsonObject doseObj = dosesArray.createNestedObject();
      doseObj["id"] = i;
      doseObj["hour"] = doses[i].hour;
      doseObj["minute"] = doses[i].minute;
      doseObj["ml"] = doses[i].ml;
      doseObj["expectedWeight"] = doses[i].expectedWeight;
      doseObj["active"] = (doses[i].hour > 0 || doses[i].minute > 0 || doses[i].ml > 0);
    }
    
    String response;
    serializeJson(doc, response);
    
    addCORSHeaders();
    server.send(200, "application/json", response);
  });

  // API endpoint to update dose schedule
  server.on("/api/doses", HTTP_POST, []() {
    if (server.hasArg("plain")) {
      String body = server.arg("plain");
      
      StaticJsonDocument<1024> doc;
      DeserializationError error = deserializeJson(doc, body);
      
      if (error) {
        addCORSHeaders();
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
      }
      
      JsonArray dosesArray = doc.as<JsonArray>();
      int doseIndex = 0;
      
      for (JsonObject doseObj : dosesArray) {
        if (doseIndex >= DOSE_COUNT) break;
        
        doses[doseIndex].hour = doseObj["hour"] | 0;
        doses[doseIndex].minute = doseObj["minute"] | 0;
        doses[doseIndex].ml = doseObj["ml"] | 0.0;
        doses[doseIndex].expectedWeight = doseObj["expectedWeight"] | 0.0;
        doseIndex++;
      }
      
      // Rebuild scrolling text with new doses
      buildExtendedText();
      
      String alertMsg = "[SYSTEM] Dose schedule updated via web";
      addAlert(alertMsg);
      
      addCORSHeaders();
      server.send(200, "application/json", "{\"success\":true}");
    } else {
      addCORSHeaders();
      server.send(400, "application/json", "{\"error\":\"No data\"}");
    }
  });

  // API endpoint to add a single dose
  server.on("/api/doses/add", HTTP_POST, []() {
    if (server.hasArg("plain")) {
      String body = server.arg("plain");
      
      StaticJsonDocument<256> doc;
      DeserializationError error = deserializeJson(doc, body);
      
      if (error) {
        addCORSHeaders();
        server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
        return;
      }
      
      // Find first available slot
      int availableSlot = -1;
      for (int i = 0; i < DOSE_COUNT; i++) {
        if (doses[i].hour == 0 && doses[i].minute == 0 && doses[i].ml == 0) {
          availableSlot = i;
          break;
        }
      }
      
      if (availableSlot == -1) {
        // No empty slots, use the last one
        availableSlot = DOSE_COUNT - 1;
      }
      
      doses[availableSlot].hour = doc["hour"] | 0;
      doses[availableSlot].minute = doc["minute"] | 0;
      doses[availableSlot].ml = doc["ml"] | 0.0;
      doses[availableSlot].expectedWeight = doc["expectedWeight"] | 0.0;
      
      buildExtendedText();
      
      String alertMsg = "[SYSTEM] New dose added";
      addAlert(alertMsg);
      
      addCORSHeaders();
      server.send(200, "application/json", "{\"success\":true}");
    } else {
      addCORSHeaders();
      server.send(400, "application/json", "{\"error\":\"No data\"}");
    }
  });

  // API endpoint to clear all doses
  server.on("/api/doses/clear", HTTP_POST, []() {
    for (int i = 0; i < DOSE_COUNT; i++) {
      doses[i].hour = 0;
      doses[i].minute = 0;
      doses[i].ml = 0;
      doses[i].expectedWeight = 0;
    }
    
    buildExtendedText();
    
    String alertMsg = "[SYSTEM] All doses cleared";
    addAlert(alertMsg);
    
    addCORSHeaders();
    server.send(200, "application/json", "{\"success\":true}");
  });

  // Debug endpoint
  server.on("/api/debug", HTTP_GET, []() {
    String response = "ESP32 Server is running!\n";
    response += "WiFi Status: " + String(WiFi.status()) + "\n";
    response += "IP Address: " + WiFi.localIP().toString() + "\n";
    response += "Free Heap: " + String(esp_get_free_heap_size()) + " bytes\n";
    response += "WiFi Connected: " + String(wifiConnected ? "YES" : "NO") + "\n";
    response += "Time Synced: " + String(timeSynced ? "YES" : "NO") + "\n";
    response += "Current Doses:\n";
    
    for (int i = 0; i < DOSE_COUNT; i++) {
      response += "  " + String(i) + ": " + String(doses[i].hour) + ":" + 
                 String(doses[i].minute) + " - " + String(doses[i].ml, 1) + 
                 "ml (" + String(doses[i].expectedWeight, 1) + "g)\n";
    }
    
    addCORSHeaders();
    server.send(200, "text/plain", response);
  });

  // Root endpoint
  server.on("/", HTTP_GET, []() {
    String html = "<html><head><title>Medicine Monitor</title></head><body>";
    html += "<h1>ESP32 Medicine Monitor</h1>";
    html += "<p>Server is running!</p>";
    html += "<p><a href='/api/status'>Status API</a></p>";
    html += "<p><a href='/api/alerts'>Alerts API</a></p>";
    html += "<p><a href='/api/doses'>Doses API</a></p>";
    html += "<p><a href='/api/debug'>Debug Info</a></p>";
    html += "</body></html>";
    
    addCORSHeaders();
    server.send(200, "text/html", html);
  });

  // Handle preflight OPTIONS requests
  server.on("/api/status", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/api/alerts", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/api/doses", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/api/doses/add", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/api/doses/clear", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/api/debug", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });

  server.begin();
  Serial.println("HTTP server started");
}

void setup() {
  Serial.begin(115200);
  delay(1000); // Give serial time to initialize
  
  Serial.println("\n=== Medicine Monitor Starting ===");
  
  // Initialize Buzzer
  pinMode(buzzerPin, OUTPUT);
  digitalWrite(buzzerPin, LOW); // Ensure buzzer is OFF initially
  
  // Initialize and turn OFF built-in LED
  pinMode(builtInLedPin, OUTPUT);
  digitalWrite(builtInLedPin, LOW);  // Turn LED OFF and keep it OFF
  
  // Initialize LCD first
  Wire.begin(SDA_PIN, SCL_PIN);
  lcd.init();
  lcd.backlight();

  // Initialize Servo Motor
  myServo.attach(servoPin);
  myServo.write(90); // Stop position

  // HX711 setup
  loadcell.begin(dataPin, clockPin);
  loadcell.set_scale(scale_factor);
  loadcell.tare(); // Initial tare
  delay(1000);
  
  // Initial splash screen with sound
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Welcome!");
  lcd.setCursor(0,1);
  lcd.print("S.I.M.S.");
  playSuccessBeep(); // Welcome sound
  delay(2000);  

  // Build initial scrolling text
  buildExtendedText();
  
  // Show home screen immediately
  lcd.clear();
  displayHomeScreen();
  
  // IMPROVED WiFi SETUP
  Serial.println("\n=== WiFi Setup ===");
  Serial.print("Connecting to: ");
  Serial.println(ssid);
  
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.persistent(true);
  
  // Start WiFi connection
  WiFi.begin(ssid, password);
  lastWiFiAttempt = millis();

  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  
  // Initialize alerts
  addAlert("System started");
  
  // Start web server immediately (don't wait for WiFi)
  setupWebServer();
  
  Serial.println("Setup complete!");
}

void loop() {
  unsigned long now = millis();

  // IMPROVED BACKGROUND WiFi CONNECT - FIXED VERSION
  if (!wifiConnected) {
    wl_status_t status = WiFi.status();
    
    if (now - lastWiFiAttempt >= wifiRetryInterval) {
      lastWiFiAttempt = now;
      
      // Declare variables outside switch to fix compilation error
      String alertMsg;
      String ip;
      
      switch(status) {
        case WL_CONNECTED:
          wifiConnected = true;
          Serial.print("✅ WiFi connected! IP: ");
          Serial.println(WiFi.localIP());
          
          alertMsg = "[SYSTEM] WiFi connected - IP: " + WiFi.localIP().toString();
          addAlert(alertMsg);
          
          buildExtendedText();
          
          // Show IP on LCD temporarily
          lcd.clear();
          lcd.setCursor(0,0);
          lcd.print("WiFi Connected");
          lcd.setCursor(0,1);
          lcd.print("IP:");
          ip = WiFi.localIP().toString();
          lcd.print(ip.substring(ip.lastIndexOf('.') + 1));
          playDoubleBeep();
          delay(3000);
          lcd.clear();
          break;
          
        case WL_NO_SSID_AVAIL:
          Serial.println("❌ WiFi: Network 'wifi1' not found");
          break;
        case WL_CONNECT_FAILED:
          Serial.println("❌ WiFi: Connection failed - check password");
          break;
        case WL_CONNECTION_LOST:
          Serial.println("❌ WiFi: Connection lost");
          break;
        case WL_DISCONNECTED:
          Serial.println("🔄 WiFi: Disconnected, reconnecting...");
          WiFi.reconnect();
          break;
        case WL_IDLE_STATUS:
          Serial.println("⏳ WiFi: Connecting...");
          break;
        default:
          Serial.printf("❓ WiFi: Unknown status %d\n", status);
          break;
      }
    }
  } else if (!timeSynced) {
    struct tm timeinfo;
    if (getLocalTime(&timeinfo, 5000)) { // 5 second timeout
      timeSynced = true;
      Serial.println("✅ Time synchronized!");
      
      String alertMsg = "[SYSTEM] Time synchronized - " + String(timeinfo.tm_hour) + ":" + String(timeinfo.tm_min);
      addAlert(alertMsg);
      
      buildExtendedText();
    } else {
      Serial.println("❌ Time sync failed");
    }
  }

  // Handle web server clients (CRITICAL - must be called frequently)
  server.handleClient();
  
  // Check for day change and rotate motor automatically
  if (timeSynced) {
    checkDayChange();
  }

  // Serial monitor commands
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    
    if (input.equalsIgnoreCase("w")) {
      float weight = loadcell.get_units();
      Serial.printf("Current weight: %.2f g\n", weight);
    } else if (input.equalsIgnoreCase("t")) {
      loadcell.tare();
      Serial.println("Manual tare performed");
      addAlert("[SYSTEM] Manual tare performed");
      playBeep();
    } else if (input.equalsIgnoreCase("d")) {
      // Enhanced debug command
      Serial.printf("Dose Active: %s\n", doseActive ? "YES" : "NO");
      Serial.printf("Vial Taken: %s\n", vialTaken ? "YES" : "NO");
      Serial.printf("Vial Replaced: %s\n", vialReplacedTime > 0 ? "YES" : "NO");
      Serial.printf("Initial Weight: %.2f g\n", initialVialWeight);
      Serial.printf("Current Weight: %.2f g\n", loadcell.get_units());
      Serial.printf("WiFi Connected: %s\n", wifiConnected ? "YES" : "NO");
      Serial.printf("WiFi Status: %d\n", WiFi.status());
      Serial.printf("Time Synced: %s\n", timeSynced ? "YES" : "NO");
      Serial.print("IP Address: ");
      Serial.println(WiFi.localIP());
      
      // Show WiFi status details
      switch(WiFi.status()) {
        case WL_NO_SHIELD: Serial.println("WiFi: No shield"); break;
        case WL_IDLE_STATUS: Serial.println("WiFi: Idle"); break;
        case WL_NO_SSID_AVAIL: Serial.println("WiFi: No SSID available"); break;
        case WL_SCAN_COMPLETED: Serial.println("WiFi: Scan completed"); break;
        case WL_CONNECTED: Serial.println("WiFi: Connected"); break;
        case WL_CONNECT_FAILED: Serial.println("WiFi: Connect failed"); break;
        case WL_CONNECTION_LOST: Serial.println("WiFi: Connection lost"); break;
        case WL_DISCONNECTED: Serial.println("WiFi: Disconnected"); break;
        default: Serial.println("WiFi: Unknown status"); break;
      }
    } else if (input.equalsIgnoreCase("r")) {
      // Enhanced WiFi reconnect
      Serial.println("🔄 Reconnecting to WiFi...");
      WiFi.disconnect();
      delay(1000);
      WiFi.begin(ssid, password);
      wifiConnected = false;
      timeSynced = false;
      lastWiFiAttempt = millis();
      Serial.println("WiFi reconnect initiated.");
      addAlert("[SYSTEM] Manual WiFi reconnect initiated");
    } else if (input.equalsIgnoreCase("wifiscan")) {
      // NEW: Scan for available networks
      Serial.println("Scanning for WiFi networks...");
      int numNetworks = WiFi.scanNetworks();
      if (numNetworks == 0) {
        Serial.println("No networks found");
      } else {
        Serial.printf("Found %d networks:\n", numNetworks);
        for (int i = 0; i < numNetworks; i++) {
          Serial.printf("%d: %s (%ddBm) %s\n", 
            i+1, 
            WiFi.SSID(i).c_str(), 
            WiFi.RSSI(i),
            (WiFi.encryptionType(i) == WIFI_AUTH_OPEN) ? "open" : "secured");
        }
      }
    } else if (input.equalsIgnoreCase("wifidetails")) {
      checkWiFiDetails();
    } else if (input.equalsIgnoreCase("b")) {
      activateBuzzer();
    } else if (input.equalsIgnoreCase("btest")) {
      testAllSounds();
    } else if (input.equalsIgnoreCase("m")) {
      rotateOneDay();
    } else if (input.equalsIgnoreCase("h")) {
      Serial.println("\n=== HELP MENU (SIMS Commands) ===");
      Serial.println("w : Display current weight (grams)");
      Serial.println("t : Perform manual tare (zero scale)");
      Serial.println("d : Display system debug information");
      Serial.println("r : Reconnect to WiFi network");
      Serial.println("wifiscan : Scan for available WiFi networks");
      Serial.println("wifidetails : Show detailed WiFi information");
      Serial.println("b : Test buzzer (double beep)");
      Serial.println("btest : Test all buzzer sounds");
      Serial.println("m : Rotate motor for 1 day (51 degrees)");
      Serial.println("h : Show this help menu");
      Serial.println("==================================\n");
    }
  }

  // Auto tare logic (only when no dose active) - SILENT VERSION
  float weight = loadcell.get_units();
  if (!doseActive) {
    // Check if weight is stable (within 0.5g for 2 seconds)
    if (abs(weight - lastStableWeight) < 0.5) {
      if (!inStableRange) {
        inStableRange = true;
        stableStart = now;
      } else if (now - stableStart >= 2000) { // Wait 2 seconds of stability
        // Tare if weight is negative OR near zero
        if (weight < -1.0 || (weight >= -1.0 && weight < 2.0)) {
          loadcell.tare();
          // Auto-tare performed silently - no alerts or serial messages
          inStableRange = false;
        }
      }
    } else {
      inStableRange = false;
      lastStableWeight = weight;
    }
  }

  // Dose management
  checkDoseStart();
  monitorDose();

  // LCD update
  if (now - lastLCDupdate >= lcdInterval) {
    lastLCDupdate = now;
    
    if (doseActive) {
      displayDoseScreen();
    } else {
      displayHomeScreen();
    }
  }

  // Smooth scrolling update (independent of LCD update)
  if (!doseActive && extendedText.length() > 16 && now - lastScrollUpdate >= scrollInterval) {
    lastScrollUpdate = now;
    
    scrollPosition++;
    
    // Reset position when we've scrolled through one complete cycle
    if (scrollPosition >= extendedText.length() - 16) {
      scrollPosition = 0;
    }
  }
}